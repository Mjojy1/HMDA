# Local verification — 2026-10-31

- Original notebook unchanged; no model training, Dataset writes, commits or pushes.
- 125,000 Dataset rows loaded; all five years validated.
- Preferred pipeline evaluation exactly matches four saved metrics (tolerance 1e-10).
- Missing preferred fairness report generated in outputs/reports, never substituted from baseline.
- 14 pytest tests passed using temporary fixtures; one upstream dateutil deprecation warning.
- TypeScript check and Vite 6.4.5 production build passed. Bundle size advisory remains.
- npm install audit: zero reported vulnerabilities after Vite/PostCSS patch updates.
- app.sh passed shell syntax checking and started Uvicorn on 0.0.0.0:8000.
- Real running API returned readiness 200 and all checks ready.
- Five dashboard pages, year filter, fairness minimum-size filter, mobile navigation, and simulated proxy prefix tested with Chromium.
- No JavaScript page errors in browser checks.
- No Domino App/Job deployed. Actual App mount and platform proxy still require App Preview verification.
